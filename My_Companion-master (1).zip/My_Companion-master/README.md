
This project includes four modules and is listed below:
 
1) Authentication
2) Add Emergency Contacts
3) Add Personal Information
4) Sending SMS

<b>Home Screen</b>

![WhatsApp Image 2021-02-10 at 12 25 11 PM (4)](https://user-images.githubusercontent.com/69119935/114031186-c0153b80-9898-11eb-858f-dc38eb8494b3.jpeg) 

<b>Signup Screen</b>

![WhatsApp Image 2021-02-10 at 12 25 11 PM (2)](https://user-images.githubusercontent.com/69119935/114031310-e2a75480-9898-11eb-80ac-050bdab1a11b.jpeg)

<b>Login Screen</b>

![WhatsApp Image 2021-02-10 at 12 25 11 PM (1)](https://user-images.githubusercontent.com/69119935/114031689-3ade5680-9899-11eb-8806-7049db49f41b.jpeg)


